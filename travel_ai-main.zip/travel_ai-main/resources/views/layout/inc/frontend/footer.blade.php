<footer class="footer  bg-light">
    <div class="container text-center p-3">
        <span class="text-muted">© {{ date('Y') }} Travel AI</span>
    </div>
</footer>
